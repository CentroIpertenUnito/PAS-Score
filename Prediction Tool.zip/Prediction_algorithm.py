from sklearn.ensemble import RandomForestClassifier
import scipy.io
import numpy as np
import pickle
filename = 'Forest_model.sav'
loaded_model = pickle.load(open(filename, 'rb'))
print ('Welcome to the prediction tool: [please use the point as separator for decimal number: e.g., 3.7 and not 3,7]')
print ('-------------------------\n')
SoleBonelli = ['Sex (Female=F; Male= M)',
        'Systolic Blood Pressure (mmHg)',
        'Antihypertensive medication (expressed as Defined Daily Dose, DDD)',
        'BMI (Kg/sqm)',
        'Lowest potassium (mEq/L)',
        'Organ damage (Yes=Y; No=N)']
Query = np.zeros((1,6))
Prediction_type = ['Lateralized PA',
'Bilateral PA']
for i in range(len(SoleBonelli)):
    String_to_print = 'Insert value of ' + SoleBonelli[i] +' and press enter:\n'
    if i==0:
        if input(String_to_print) == 'F':
            Query[0,i] = 1
        else:
            Query[0,i] = 2
    elif i==5:
        inp = input(String_to_print)
        if inp == 'Y':
            Query[0,i] = 1
        else:
            Query[0,i] = 0
    else:
        Query[0,i] = input(String_to_print)

Prediction = loaded_model.predict(Query)
perc_positive_screening = ['0.0', '0.5', '9.3', '11.0', '15.0', '22.9', '30.4', '32.5', '46.9', '71.6']
perc_pa_risk = ['0.0', '0.2', '1.5', '3.5', '5.4', '13.1', '19.9', '22.2', '40.7', '67.7']
perc_upa_risk = ['0.0', '0.0', '0.0', '0.0', '0.2', '2.7', '4.1', '5.9', '13.9', '41.3']
i = 0
for values in [0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]:
    if Prediction >= values and Prediction < (values + 0.1):
        print('The probability of a positive screening test is: '+ perc_positive_screening[i] + ' %')
        print('The probability of PA diagnosis is: '+ perc_pa_risk[i] + ' %')
        print('The probability of unilateral PA is: '+ perc_upa_risk[i] + ' %')
    i+=1

if Prediction < 0.3:
    print ('------------')
    print ('Screening test not strictly recommended')
else:
    print ('------------')
    print ('Perform screening test for PA')
